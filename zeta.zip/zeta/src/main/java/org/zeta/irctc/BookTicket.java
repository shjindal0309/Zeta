package org.zeta.irctc;

import org.zeta.irctc.impl.TicketImpl;
import org.zeta.irctc.impl.TrainImpl;
import org.zeta.irctc.impl.UserImpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/*

A --> B --> C --> D

10

1st 6 from A-->B, remaining seats 4
2nd 7


*/
public class BookTicket {

    private static Map<Integer, Integer> trainSeatAvailability = new HashMap<>();
    private static Map<String, TrainImpl> trainSchedules = new HashMap<>();
    private static Map<Integer, UserImpl> userDetails = new HashMap<>();
    private static Map<Integer, Integer> ticketTrainId = new HashMap<>();
    private static Integer ticketId;

    public static void main(String[] args) {
        initializeTrainSchedules();

        UserQuery userQuery = new UserQuery("A", "B",1);
        bookTicket(userQuery);
        userQuery = new UserQuery("A", "B",1);
        bookTicket(userQuery);
        userQuery = new UserQuery("A", "B",1);
        bookTicket(userQuery);
        userQuery = new UserQuery("A", "B",1);
        bookTicket(userQuery);


        cancelTicket(1);


    }
    public static void bookTicket(UserQuery userQuery) {

        String trainScheduleKey = userQuery.getSource() + "." + userQuery.getDestination();

        if(trainSchedules.containsKey(trainScheduleKey) &&
                trainSeatAvailability.get(trainSchedules.get(trainScheduleKey).getTrainId()) > 0) {

            Integer trainId = trainSchedules.get(userQuery.getSource() + "." + userQuery.getDestination()).getTrainId();
            Integer availableSeats = trainSeatAvailability.get(trainSchedules.get(trainScheduleKey).getTrainId());

            TicketImpl ticket = new TicketImpl(trainId, ticketId+1, userQuery.getSource(), userQuery.getDestination());
            ticketTrainId.put(ticketId+1,trainId);
            trainSeatAvailability.put(trainId, availableSeats-1);
            ticketId = ticketId + 1;
            System.out.println(ticket);
        }
    }

    public static void cancelTicket(Integer ticketId) {
        Integer trainId = ticketTrainId.get(ticketId);
        trainSeatAvailability.put(trainId, trainSeatAvailability.get(trainId)+1);
    }

    public static void initializeTrainSchedules() {
//        LocalDateTime time = new LocalDateTime()

        TrainImpl train = new TrainImpl(1, "A", "B", time, 2);
        trainSchedules.put("A+B", train);

        train = new TrainImpl(1, "A", "B", time, 2);
        trainSchedules.put("A+B", train);

        train = new TrainImpl(1, "A", "B", time, 2);
        trainSchedules.put("A+B", train);

        train = new TrainImpl(1, "A", "B", time, 2);
        trainSchedules.put("A+B", train);
    }
}
