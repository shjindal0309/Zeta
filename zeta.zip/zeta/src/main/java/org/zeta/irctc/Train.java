package org.zeta.irctc;

public interface Train {
}
