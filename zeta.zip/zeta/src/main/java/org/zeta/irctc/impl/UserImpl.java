package org.zeta.irctc.impl;

public class UserImpl {
    private Integer userId;
    private Integer contactNo;
    private String name;

    public UserImpl(Integer userId, Integer contactNo, String name) {
        this.name = name;
        this.userId = userId;
        this.contactNo = contactNo;
    }

    public String getName() {
        return this.name;
    }

    public Integer getContactNo() {
        return this.contactNo;
    }
}
