package org.zeta.irctc.impl;

import java.time.LocalDateTime;

public class TrainImpl {
    private Integer trainId;
    private String source;
    private String destination;
    private LocalDateTime startTime;
    private Integer journeyDuration;

    public TrainImpl(Integer trainId, String source, String destination, LocalDateTime startTime, Integer journeyDuration) {
        this.destination = destination;
        this.source = source;
        this.trainId = trainId;
        this.startTime = startTime;
        this.journeyDuration = journeyDuration;
    }

    public Integer getTrainId() {
        return this.getTrainId();
    }
}
