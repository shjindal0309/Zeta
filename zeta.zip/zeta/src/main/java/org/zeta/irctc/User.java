package org.zeta.irctc;

public interface User {
}
