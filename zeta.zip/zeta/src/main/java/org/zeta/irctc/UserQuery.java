package org.zeta.irctc;

public class UserQuery {

    private String source;
    private String destination;
    private Integer userId;

    public UserQuery(String source, String destination, Integer userId) {
        this.source = source;
        this.destination = destination;
        this.userId = userId;
    }

    public String getSource() {
        return this.source;
    }
    public String getDestination() {
        return this.destination;
    }
    public Integer getUserId() {
        return this.userId;
    }
}
