package org.zeta.irctc.impl;

public class TicketImpl {
    private Integer trainId;
    private Integer ticketId;
    private String source;
    private String destination;
    private Integer seatNo;

    public TicketImpl(Integer trainId, Integer ticketId, String source, String destination) {
        this.trainId = trainId;
        this.ticketId = ticketId;
        this.source = source;
        this.destination = destination;
    }

    public Integer getTrainId() {
        return this.trainId;
    }

    public void setTrainId(Integer trainId) {
        this.trainId = trainId;
    }
    public Integer getTicketId() {
        return this.ticketId;
    }

    public void setTicketId(Integer ticketId) {
        this.ticketId = ticketId;
    }
}
