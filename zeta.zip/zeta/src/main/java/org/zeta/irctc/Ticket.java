package org.zeta.irctc;

public interface Ticket {

}
